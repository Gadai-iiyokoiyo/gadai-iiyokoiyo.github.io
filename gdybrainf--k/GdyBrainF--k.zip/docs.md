# GBF

## Writing
Example:
```
gbf1
c5c/c2c=dCaaaaaaAaaaGAe
```
Return:
```
5/2=2.5
```
var:  
|name|function|
|---|---|
|_l_|save the float and int type|
|_lp_|Used to specify the number of *l*|
|_s_|save the text|

function:
|name|function|
|---|---|
|_a_|CountUP _l[lp]_|
|_A_|CountUP _lp_|
|_b_|CountDOWN _l[lp]_|
|_B_|CountDOWN _lp_|
|_c_|Add the following one character to _s_|
|_C_|Clear _s_|
|_d_|PrintOut _s_|
|_e_|PrintOut _l[lp]_|

function(calc):
### f
_l[lp+1]_ = _l[lp-1]_ + _l[lp]_  
example:  
```
gbf1
aaaA
aaaa
```
_l_ = [2,3,0,0,0...0]
```
fAe
```
_l_ = [2,3,5,0,0...0]
***
### F
_l[lp+1]_ = _l[lp-1]_ * _l[lp]_  
example:  
```
gbf1
aaaA
aaaa
```
_l_ = [2,3,0,0,0...0]
```
FAe
```
_l_ = [2,3,6,0,0...0]
### g
_l[lp+1]_ = _l[lp-1]_ - _l[lp]_  
example:  
```
gbf1
aaaA
aaaa
```
_l_ = [2,3,0,0,0...0]
```
gAe
```
_l_ = [2,3,-1,0,0...0]
***
### G
_l[lp+1]_ = _l[lp-1]_ / _l[lp]_  
example:  
```
gbf1
aaaA
aaaa
```
_l_ = [2,3,0,0,0...0]
```
gAe
```
_l_ = [2,3,0.666667,0,0...0]
***

#### What happens if you try to divide by zero?
```
gbf1
aaaAA
GAe
```
```
What happens if you try to divide by zero?
```